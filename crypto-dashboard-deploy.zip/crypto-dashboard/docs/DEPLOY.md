# Deployment Guide

This is a build-free static site (`index.html` + `styles/` + `src/`) with two
[Vercel](https://vercel.com/) serverless functions in `api/`. There is **no build step**
and **no `npm install`** — Vercel serves the static files and runs `api/*.js` as functions.

## Prerequisites

- A Vercel account.
- A **CoinMarketCap Pro API key** (`CMC_API_KEY`). Ask the project owner for the value —
  it is **not** included in this package and must never be committed.

## Option A — Deploy on Vercel (recommended)

1. Put these files in a Git repo (GitHub/GitLab/Bitbucket) **or** drag-and-drop the folder
   into Vercel.
2. In Vercel, **New Project** → import the repo/folder.
   - Framework Preset: **Other**
   - Build Command: *(leave empty)*
   - Output Directory: *(leave empty / root)*
   - Root Directory: **the folder that contains `index.html` and `api/`** (the repo root).
3. **Settings → Environment Variables**, add:
   | Name | Value | Environments |
   |---|---|---|
   | `CMC_API_KEY` | *(the CoinMarketCap Pro key)* | Production **and** Preview |
4. **Deploy.** Vercel auto-detects `api/quotes.js` and `api/history.js` as serverless
   functions at `/api/quotes` and `/api/history`.

After the first import, every push to the production branch redeploys automatically.

## Option B — Vercel CLI

```bash
npm i -g vercel
vercel                      # first run: link/create the project
vercel env add CMC_API_KEY  # paste the key; choose Production + Preview
vercel --prod               # production deploy
```

## Verify after deploy

- The page loads and the status light turns **LIVE** (green) within ~60s.
- `https://<your-deployment>/api/quotes` returns JSON with a `data` array.
- `https://<your-deployment>/api/history` returns JSON with a `months` array.

If the light stays **SNAPSHOT** (red), `CMC_API_KEY` is missing or invalid — recheck the
environment variable, then redeploy.

## Important

- Keep `index.html` and `api/` at the **root** of the deployed project (Vercel zero-config
  relies on this). Do not move them into a subfolder without adding a `vercel.json`.
- The API key is read **server-side only** (`api/quotes.js`, `api/history.js`) and is never
  sent to the browser.

## Local preview (optional)

ES modules require `http(s)`, not `file://`:

```bash
python -m http.server 8765
# open http://127.0.0.1:8765/index.html
```

Locally `/api/*` returns 404 (no serverless runtime), so the page shows SNAPSHOT with
fallback data — that is expected. Live data only works on a Vercel deployment.
